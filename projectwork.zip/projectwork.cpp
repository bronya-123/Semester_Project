#include <iostream>
using namespace std;

// PATIENT BRONYA DETAILS //

 //david password//
   string password1="bronya1234";
  string b_password; 
  
 // function for david 
  void David(){
cout<<"\nPERSONAL_INFORMATION"<<"              CONTACT_INFORMATION"<<"           LAB_RESULT"<<"               DISEASE"<<endl;
// personal info		    		//contact info		 
cout<<"**************************************************************************************************";
cout<<"\nNAME: BRONYA KWASI DAVID";cout<<"            ADDRESS:KWB124";cout<<"              RED BLOOD CELL";cout<<"       TUBERCLOSIS";
cout<<"\nGENDER: MALE";cout<<"                       PHONE:053333333"; cout<<"            TRIGLYCERIDES";cout<<"         MALARIA";
cout<<"\nDATA OF BIRTH: 26/12/1905";cout<<"          EMAIL:bronya@gmail.com";cout<<"         PROIEN";cout<<"              COVID 19";
cout<<"\nMARITAL STATUS: SINGLE"<<     "     "<<"          ";			cout<<"     	                                      CANCER";					
 
    }
    
    

 // PATIENT RASHID DETAILS//
  
  // Rashid password//
     string password2="rashid1234";
     string r_password;
  void Rashid(){
cout<<"\nPERSONAL_NFORMATION"<<"              CONTACT_NFORMATION"<<"      LAB_RESULT"<<"               DISEASE"<<endl;
// personal infor 		    		//contact info		 
cout<<"\nNAME: RASHID EMMORO";cout<<"            ADDRESS:KINSS124";cout<<"              RED BLOOD CELL";cout<<"       TUBERCLOSIS";
cout<<"\nGENDER: MALE";cout<<"                       PHONE:0547366085"; cout<<"            TRIGLYCERIDES";cout<<"         MALARIA";
cout<<"\nDATA OF BIRTH: 26/01/1840";cout<<"          EMAIL:EMMORO@gmail.com";cout<<"         PROIEN";cout<<"              COVID 19";
cout<<"\nMARITAL STATUS: MARRID"<<     "     "<<"          ";			cout<<"     	                                      CANCER";					
 
    }
   
    

  
// PATIENT iddrisu DETAILS//

//iddrisu password//
  string password3="iddrisu1234";
  string e_password;

  void IDDRISU(){
cout<<"\nPERSONAL_NFORMATION"<<"              CONTACT_NFORMATION"<<"      LAB_RESULT"<<"               DISEASE"<<endl;
// personal infor 		    		//contact info		 
cout<<"\nNAME: IDDRISU ISHAQ";cout<<"              ADDRESS:KER124";cout<<"              RED BLOOD CELL";cout<<"       TUBERCLOSIS";
cout<<"\nGENDER: MALE";cout<<"                       PHONE:0240070088"; cout<<"            TRIGLYCERIDES";cout<<"         MALARIA";
cout<<"\nDATA OF BIRTH: 29/10/2O19";cout<<"          EMAIL:IDDRISU@gmail.com";cout<<"         PROIEN";cout<<"              COVID 19";
cout<<"\nMARITAL STATUS: SINGLE"<<     "     "<<"          ";			cout<<"     	                                      CANCER";					
 
    }
    
    

// PATIENT ESTHER DETAILS//

 // esther's password//
    string password4="esther1234";
   string i_password;
   
 void ESTHER(){
cout<<"\nPERSONAL_NFORMATION"<<"              CONTACT_NFORMATION"<<"           LAB_RESULT"<<"               DISEASE"<<endl;
// personal infor 		    		//contact info		 //LAB_RESULT INFO		DISEASE
cout<<"\nNAME: AMA ESTHER";cout<<"               ADDRESS:KZB124";cout<<"              RED BLOOD CELL";cout<<"       TUBERCLOSIS";
cout<<"\nGENDER: FEMALE";cout<<"                       PHONE:0559968786"; cout<<"            TRIGLYCERIDES";cout<<"         MALARIA";
cout<<"\nDATA OF BIRTH: 26/12/1999";cout<<"          EMAIL:ESTHER@gmail.com";cout<<"         PROIEN";cout<<"              COVID 19";
cout<<"\nMARITAL STATUS: SINGLE"<<     "     "<<"          ";			cout<<"     	                                      CANCER";					
 
    }
    
   
    



int main() {
 int select;

 
cout<<"  \n ***THIS PROGRAM IS DESIGN TO CHECK FOR PATIENT INFORMATION!***"<<endl;
 system("pause");
 cout<<"\n********************************************"<<endl;
 cout<<"SELCET THE NAME OF THE PATIENT YOU WANT TO CHECK HIS/HER INFORMATION."<<endl<<endl;
cout<<" 1.Bronya David"<<endl;
cout<<" 2.Rashid Emmoro"<<endl;
cout<<" 3.Iddrisu Ishaq"<<endl;
cout<<" 4.AMA ESTHER"<<endl;
cout<<"Select a patient from the list: ";
cin>>select;
 switch(select){

// accessing bronya's information
   case 1:
 for(int i=0;i<=3;i++){
     cout<<"\nEnter bronya password: ";
     cin>>b_password;
       if(b_password==password1){
	   David();
	 break;
       }
        
       
       else{
       	cout<<"Invalid.Try again\n";   
       }
 }
  if(b_password!=password1){
  
	  cout<<"Attempt over!";
	  return 0;
}
return 0;

// accessing rashid information
 case 2:
 	
  for(int i=0;i<=3;i++){
     cout<<"\nEnter rashid password: ";
     cin>>r_password;
       if(r_password==password2){
	 Rashid();
	 break;
       }
        
       
       else{
       	cout<<"Invalid.Try again\n";   
       }
 } 
 if(r_password!=password2){
  cout<<"Attempt over!";
  return 0;
}
	


//accessing iddrisu details//
 case 3:
 		
  for(int i=0;i<=3;i++){
     cout<<"\nEnter iddrisu password: ";
     cin>>i_password;
       if(i_password==password3){
	 IDDRISU();
	 break;
       }
        
       
       else{
       	cout<<"Invalid.Try again\n";   
       }
 } 
 if(i_password!=password3){
  cout<<"Attempt over!";
  return 0;
}

//accesing esther details//

case 4:
	
  for(int i=0;i<=3;i++){
     cout<<"\nEnter esther password: ";
     cin>>e_password;
       if(e_password==password4){
	ESTHER();
	 break;
       }
        
       
       else{
       	cout<<"Invalid.Try again\n";   
       }
 } 
 if(e_password!=password4){
  cout<<"Attempt over!";
  return 0;
}

return 0;
}
}

